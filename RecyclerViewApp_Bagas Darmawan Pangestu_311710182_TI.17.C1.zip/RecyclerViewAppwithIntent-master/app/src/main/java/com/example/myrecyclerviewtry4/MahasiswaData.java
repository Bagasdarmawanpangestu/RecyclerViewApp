package com.example.myrecyclerviewtry4;

import java.util.ArrayList;

public class MahasiswaData {
    private static String[] mahasiswaNama = {
            "Bagas Darmawan Pangestu",
            "Seruni Cahya Nughraheni",
            "Giri Baldy Stachbanny"

    };

    private static String[] mahasiswaNim = {
            "311710xxx",
            "311710xxx",
            "311710xxx"

    };

    private static String[] mahasiswaHp = {
            "08xx-xxxx-xxxx",
            "08xx-xxxx-xxxx",
            "08xx-xxxx-xxxx"
    };

    private static int[] mahasiswaImage = {
            R.drawable.default_pic,
            R.drawable.default_pic,
            R.drawable.default_pic

    };

    static ArrayList<Mahasiswa> getListData() {
        ArrayList<Mahasiswa> list = new ArrayList<>();
        for (int position =0; position < mahasiswaNama.length; position++) {
            Mahasiswa mahasiswa = new Mahasiswa();
            mahasiswa.setNama(mahasiswaNama[position]);
            mahasiswa.setNim(mahasiswaNim[position]);
            mahasiswa.setPhoto(mahasiswaImage[position]);
            mahasiswa.setNoHp(mahasiswaHp[position]);
            list.add(mahasiswa);
        }
        return list;
    }
}
