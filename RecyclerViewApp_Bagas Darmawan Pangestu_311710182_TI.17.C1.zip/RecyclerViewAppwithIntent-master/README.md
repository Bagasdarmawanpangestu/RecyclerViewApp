# RecyclerViewAppwithIntent
Nama: Andi Purnama

![photo_2020-04-12_14-05-38](https://user-images.githubusercontent.com/37577215/79062781-3fdcea00-7cc7-11ea-8f39-0ca04b20e6b4.jpg)

![photo_2020-04-12_14-05-40](https://user-images.githubusercontent.com/37577215/79062779-3e132680-7cc7-11ea-8698-dd3fbf293c00.jpg)

![photo_2020-04-12_14-05-43](https://user-images.githubusercontent.com/37577215/79062775-3b183600-7cc7-11ea-968f-75265bc12c4f.jpg)
